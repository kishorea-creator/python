# Python
These files are mainly intended to accompany my series of YouTube tutorial videos here, 
https://www.youtube.com/user/joejamesusa
and are mainly intended for educational purposes.
You are invited to subscribe to my video channel, and to download and use any code in 
this Python repository, according to the MIT License. 
Feel free to post any comments on my YouTube channel.

Joe James.
Fremont, California.
Copyright (C) 2015-2019, Joe James
